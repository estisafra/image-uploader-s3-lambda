const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const s3 = new S3Client({ region: "us-east-1" }); // שנה אזור לפי הצורך

const bucketName = 'image-upload-327-bucket';

exports.handler = async (event) => {
    try {
        const body = event.isBase64Encoded
            ? Buffer.from(event.body, 'base64')
            : Buffer.from(event.body);

        const timestamp = Date.now();
        const originalKey = `images/original_${timestamp}.jpg`;

        const command = new PutObjectCommand({
            Bucket: bucketName,
            Key: originalKey,
            Body: body,
            ContentType: 'image/jpeg',
            ACL: 'public-read',
        });

        await s3.send(command);

        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            body: JSON.stringify({
                originalImageUrl: `https://${bucketName}.s3.amazonaws.com/${originalKey}`,
            }),
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Error", error: error.message }),
        };
    }
};
